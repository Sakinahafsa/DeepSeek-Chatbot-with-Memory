from langchain_community.llms import Ollama
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
import streamlit as st

# Streamlit UI
st.set_page_config(page_title="🧠 DeepSeek Chatbot", layout="centered")
st.title("🤖 DeepSeek Chatbot with Memory")

# Input field
user_input = st.text_input("Ask anything...")

# Load DeepSeek model from Ollama
llm = Ollama(model="deepseek-r1:1.5b")

# Memory to store conversation history
memory = ConversationBufferMemory()

# Build chain
conversation = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=False
)

# Process user input
if user_input:
    response = conversation.predict(input=user_input)
    st.write("**Bot:**", response)

    # Show past conversation
    with st.expander("🧾 Chat History"):
        for msg in memory.chat_memory.messages:
            role = "🧑 You" if msg.type == "human" else "🤖 Bot"
            st.write(f"{role}: {msg.content}")

